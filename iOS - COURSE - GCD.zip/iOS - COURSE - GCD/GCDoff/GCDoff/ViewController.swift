//
//  ViewController.swift
//  GCDoff
//
//  Created by Marcos Bittencourt on 30/03/17.
//  Copyright © 2017 Marcos Bittencourt. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    
    //MARK: Properties
    @IBOutlet weak var image: UIImageView!
    @IBOutlet weak var activity: UIActivityIndicatorView!
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        activity.stopAnimating()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    // MARK: Action
    // Those methods just call the updateImage method
    @IBAction func photo1(_ sender: UIButton) {
        updateImage(1)
    }
    
    
    @IBAction func photo2(_ sender: UIButton) {
        updateImage(2)
    }
    

    @IBAction func photo3(_ sender: UIButton) {
        updateImage(3)
    }
    
    // MARK: Private method
    func updateImage(_ button: Int){
        // starts the download indicator
        activity.startAnimating()
        
        // getting the image's url
        var url = URL(string: "")
        switch button {
        case 1:
            url = URL(string: "http://wallpaper-gallery.net/images/high-quality-wallpaper-download/high-quality-wallpaper-download-1.jpg")
        case 2:
            url = URL(string: "http://wallpaper-gallery.net/images/flowers-hd-wallpaper/flowers-hd-wallpaper-14.jpg")
        case 3:
            url = URL(string: "http://wallpaper-gallery.net/blog/best-photos-taken-during-traveling-trips-in-2015/best-photos-taken-during-traveling-trips-in-2015-22.jpg")
        default:
            break
        }
        
        // Image data capture
        let fetch = NSData(contentsOf: url! as URL)
        
        // Image Show
        if let imageData = fetch {
            self.image.image = UIImage(data: imageData as Data)
        }

        
        // stops the download indicator
        activity.stopAnimating()
    }
    
}

