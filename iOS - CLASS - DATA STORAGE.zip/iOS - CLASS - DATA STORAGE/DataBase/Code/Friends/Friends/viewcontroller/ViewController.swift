import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var nameField: UITextField!
    @IBOutlet weak var phoneField: UITextField!
    @IBOutlet weak var tableview: UITableView!
    
    @IBOutlet weak var emailTableview: UITableView!
    
    
    var delegate: FriendsDelegate? = nil
    var friend: Friend?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if let friend = friend {
            nameField.text = friend.name
            phoneField.text = friend.phone
        } else {
            self.friend = Friend(id: 0, name: "", phone: "", emails: [])
        }
        
        emailTableview.register(UITableViewCell.self, forCellReuseIdentifier: "emailCell")
        emailTableview.delegate = self
        emailTableview.dataSource = self
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func saveButton(_ sender: UIBarButtonItem) {
        var result = false
        
        guard let name = nameField.text,
            !name.isEmpty else {
            let alert = UIAlertController(title: "Error", message: "Friend without name", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
            return
        }
        
        let phone = phoneField.text ?? ""
        
        if let delegate = delegate {
            // Update a friend
            if !(friend == nil) {
                friend?.name = name
                friend?.phone = phone
                result = delegate.save(friend!)
            } else {
                // new friend
                friend = Friend(id: 0, name: name, phone: phone, emails: [])
                result = delegate.save(friend!)
            }
        }
        
        if result {
            let alert = UIAlertController(title: "Saved", message: "Friend \(name) saved", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: { _ in
                if let delegate = self.delegate {
                    DispatchQueue.main.async { [unowned self] in
                        delegate.reload()
                        self.navigationController?.popViewController(animated: true)
                    }
                }
            }))
            self.present(alert, animated: true, completion: nil)

        } else {
            let alert = UIAlertController(title: "Error", message: "Friend \(name) not saved", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
    }
    
    @IBAction func addEmail(_ sender: UIButton) {
        emailAlertWindow(-1)
    }
    
    func emailAlertWindow(_ index: Int) {
        let alertController = UIAlertController(title: "Add New Email", message: "", preferredStyle: .alert)
        alertController.addTextField { (textField : UITextField!) -> Void in
            if index >= 0,
                let email = self.friend?.emails[index] {
                textField.text = email
            } else {
                textField.placeholder = "Enter Email"
            }
            
        }
        let saveAction = UIAlertAction(title: "Save", style: .default, handler: { alert -> Void in
            let emailField = alertController.textFields![0] as UITextField
            if let email = emailField.text,
                !email.isEmpty {
                if index >= 0 {
                    self.friend?.emails[index] = email
                } else {
                    self.friend?.emails.append(email)
                }
                self.emailTableview.reloadData()
            }
        })
        let cancelAction = UIAlertAction(title: "Cancel", style: .default, handler: { (action : UIAlertAction!) -> Void in })
        
        
        alertController.addAction(saveAction)
        alertController.addAction(cancelAction)
        
        self.present(alertController, animated: true, completion: nil)
    }
    
}

extension ViewController: UITableViewDelegate, UITableViewDataSource {

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if let emails = friend?.emails.count {
            return emails
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "emailCell", for: indexPath)
        if let email = friend?.emails[indexPath.row] {
            cell.textLabel?.text = email
        } else {
            cell.textLabel?.text = ""
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        emailAlertWindow(indexPath.row)
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            friend?.emails.remove(at: indexPath.row)
            if let delegate = delegate,
                let friend = friend {
                delegate.updateEmails(friend)
            }
            tableView.deleteRows(at: [indexPath], with: .fade)
            
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }
    }
}
