import UIKit

protocol FriendsDelegate {
    func save(_ friend: Friend) -> Bool
    func reload()
    func updateEmails(_ friend: Friend)
}

class FriendsTableViewController: UITableViewController {

    var friends: [Friend] = []
    var db: DBManager?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        db = DBManager()
        friends.removeAll()
        if let db = db {
            friends = db.readValues()
        }

    }
    
    override func viewDidAppear(_ animated: Bool) {
        if let db = db {
            friends.removeAll()
            friends = db.readValues()
            tableView.reloadData()
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return friends.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "friendsCell", for: indexPath)
        cell.textLabel?.text = friends[indexPath.row].name

        return cell
    }
    
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            if let db = db {
                let friend = friends[indexPath.row]
                db.delete(friend)
                friends.remove(at: indexPath.row)
            }
            tableView.deleteRows(at: [indexPath], with: .fade)
            
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }



    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let viewcontroller = segue.destination as? ViewController {
            viewcontroller.delegate = self
            if segue.identifier == "updateFriend" {
                if let index = tableView.indexPathForSelectedRow?.row,
                    index < friends.count {
                    viewcontroller.friend = friends[index]
                }
            }
        }
    }
}

extension FriendsTableViewController: FriendsDelegate {
    func updateEmails(_ friend: Friend) {
        if let db = db {
            db.delete(friend.id)
            db.save(friend.emails, idFriend: Int32(friend.id))
        }
    }
    
    func save(_ friend: Friend) -> Bool {
        if let db = db {
            return db.save(friend)
        }
        return false
    }
    
    func reload() {
        self.tableView.reloadData()
    }
}
