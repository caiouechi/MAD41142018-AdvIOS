import Foundation

struct Friend {
    let id: Int
    var name: String
    var phone: String
    var emails: [String]
}
