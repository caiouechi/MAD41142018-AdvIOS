import UIKit
import SQLite3

class DBManager {
    
    var db: OpaquePointer?
    
    init(){
        let fileURL = try! FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false).appendingPathComponent("Friends.sqlite")
        
        
        if sqlite3_open(fileURL.path, &db) != SQLITE_OK {
            print("error opening database")
        }
        
        if sqlite3_exec(db, "CREATE TABLE IF NOT EXISTS Friends (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, phone TEXT)", nil, nil, nil) != SQLITE_OK {
            let errmsg = String(cString: sqlite3_errmsg(db)!)
            print("error creating table: \(errmsg)")
        }
        
        if sqlite3_exec(db, "CREATE TABLE IF NOT EXISTS Emails (id INTEGER PRIMARY KEY AUTOINCREMENT, idFriend INTEGER, email TEXT)", nil, nil, nil) != SQLITE_OK {
            let errmsg = String(cString: sqlite3_errmsg(db)!)
            print("error creating table: \(errmsg)")
        }
    }
    
    func readValues() -> [Friend] {
        var friends: [Friend] = []
        
        let queryFriends = "SELECT * FROM Friends"
        
        var readFriend:OpaquePointer?
        
        if sqlite3_prepare(db, queryFriends, -1, &readFriend, nil) != SQLITE_OK{
            let errmsg = String(cString: sqlite3_errmsg(db)!)
            print("error preparing insert: \(errmsg)")
            return []
        }
        
        while(sqlite3_step(readFriend) == SQLITE_ROW) {
            let id = sqlite3_column_int(readFriend, 0)
            let name = String(cString: sqlite3_column_text(readFriend, 1))
            var phone = ""
            if let phoneDB = sqlite3_column_text(readFriend, 2) {
                phone = String(cString: phoneDB)
            }
            var friend = Friend(id: Int(id), name: name, phone: phone, emails: [])
            
            let queryEmails = " SELECT email FROM Emails WHERE idFriend = \(id)"
            var  stmtEmail: OpaquePointer?
            if sqlite3_prepare(db, queryEmails, -1, &stmtEmail, nil) != SQLITE_OK {
                let errmsg = String(cString: sqlite3_errmsg(db)!)
                print("error preparing insert: \(errmsg)")
                return []
            }
            while (sqlite3_step(stmtEmail) == SQLITE_ROW) {
                let email = String(cString: sqlite3_column_text(stmtEmail, 0))
                friend.emails.append(email)
            }
            
            friends.append(friend)
            sqlite3_finalize(stmtEmail)
        }
        sqlite3_finalize(readFriend)
        return friends
    }
    
    func save(_ friend: Friend) -> Bool{
        let id = friend.id
        let name = friend.name
        let phone = friend.phone
        
        if name.isEmpty {
            return false
        }
        
        // New Friend
        if id == 0 {
            var saveNew: OpaquePointer?
            let query = "INSERT INTO Friends (name, phone) VALUES ('\(name)', '\(phone)')"
            
            if sqlite3_prepare(db, query, -1, &saveNew, nil) != SQLITE_OK{
                let errmsg = String(cString: sqlite3_errmsg(db)!)
                print("error preparing insert: \(errmsg)")
                return false
            }
            
            //executing the query to insert values
            if sqlite3_step(saveNew) != SQLITE_DONE {
                let errmsg = String(cString: sqlite3_errmsg(db)!)
                print("failure inserting friend: \(errmsg)")
                return false
            }
            
            let queryID = "SELECT last_insert_rowid()"
            
            if sqlite3_prepare(db, queryID, -1, &saveNew, nil) != SQLITE_OK{
                let errmsg = String(cString: sqlite3_errmsg(db)!)
                print("error preparing insert: \(errmsg)")
                return false
            }
            
            if (sqlite3_step(saveNew) == SQLITE_ROW) {
                let id = sqlite3_column_int(saveNew, 0)
                self.save(friend.emails, idFriend: id)
            }
            sqlite3_finalize(saveNew)
            
        } else {
            // Update a friend
            let updateStatementString = "UPDATE Friends SET name = '\(friend.name)', phone = '\(friend.phone)' WHERE id = \(friend.id);"
            
            var updateStatement: OpaquePointer? = nil
            if sqlite3_prepare_v2(db, updateStatementString, -1, &updateStatement, nil) == SQLITE_OK {
                if sqlite3_step(updateStatement) == SQLITE_DONE {
                    delete(id)
                    self.save(friend.emails, idFriend: Int32(friend.id))
                    print("Successfully updated row.")
                } else {
                    print("Could not update row.")
                }
            } else {
                print("UPDATE statement could not be prepared")
            }
            sqlite3_finalize(updateStatement)
        }
        return true
    }
    
    func save (_ emails: [String], idFriend: Int32) {
        var emailInsert: OpaquePointer?

        for email in emails {
            let query = "INSERT INTO Emails (idFriend, email) VALUES (\(idFriend), '\(email)')"

            if sqlite3_prepare(db, query, -1, &emailInsert, nil) != SQLITE_OK{
                let errmsg = String(cString: sqlite3_errmsg(db)!)
                print("error preparing insert: \(errmsg)")
                return
            }
            
            if sqlite3_step(emailInsert) != SQLITE_DONE {
                let errmsg = String(cString: sqlite3_errmsg(db)!)
                print("failure inserting friend: \(errmsg)")
                return 
            }
        }
        sqlite3_finalize(emailInsert)
    }
    
    // delete emails
    func delete (_ id: Int) {
        let query = "DELETE FROM Emails WHERE idFriend = \(id);"

        var deleteStatement: OpaquePointer? = nil
        if sqlite3_prepare_v2(db, query, -1, &deleteStatement, nil) == SQLITE_OK {
            if sqlite3_step(deleteStatement) == SQLITE_DONE {
                print("Successfully deleted row.")
            } else {
                print("Could not delete row.")
            }
        } else {
            print("DELETE statement could not be prepared")
        }

        sqlite3_finalize(deleteStatement)
    }
    
    func delete (_ friend: Friend) {
        delete(friend.id)
        let query = "DELETE FROM Friends WHERE id = \(friend.id);"
        
        var deleteFriend: OpaquePointer? = nil
        if sqlite3_prepare_v2(db, query, -1, &deleteFriend, nil) == SQLITE_OK {
            if sqlite3_step(deleteFriend) == SQLITE_DONE {
                print("Successfully deleted row.")
            } else {
                print("Could not delete row.")
            }
        } else {
            print("DELETE statement could not be prepared")
        }
        
        sqlite3_finalize(deleteFriend)
    }
}
