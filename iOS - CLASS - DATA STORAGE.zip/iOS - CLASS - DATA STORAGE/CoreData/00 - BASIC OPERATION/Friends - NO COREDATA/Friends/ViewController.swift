//
//  ViewController.swift
//  Friends
//
//  Created by Marcos Bittencourt on 2017-07-12.
//  Copyright © 2017 https://ca.linkedin.com/in/marcosbittencourt. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var tableview: UITableView!
    
    var names: [String] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        title = "My Friends"
        tableview.register(UITableViewCell.self,forCellReuseIdentifier: "Cell")
    }

    @IBAction func addName(_ sender: Any) {
        
        // Create a Modal to receive data form user
        let alert = UIAlertController(title: "New Name",
                                      message: "Add a new name",
                                      preferredStyle: .alert)
        
        // Create a button save to be used in A Modal
        let saveAction = UIAlertAction(title: "Save", style: .default) {
            
            // Create a data Entry to the user. Type the name of your friend
            [unowned self] action in
            guard let textField = alert.textFields?.first,
                let nameToSave = textField.text
                else {
                    return
            }
            
            self.names.append(nameToSave) // Call func = save to save the data (data entry)
            self.tableview.reloadData() //  Call reloadData() to refresh screen and release the modal
            
        }
        
        // Create a button cancel and release the modal
        let cancelAction = UIAlertAction(title: "Cancel", style: .default)
        
        // Adding ... propreties in Modal (save and cancel)
        alert.addTextField()
        alert.addAction(saveAction)
        alert.addAction(cancelAction)
        
        // Show the Modal to the user
        present(alert, animated: true)
        
    }
    
}
    
// MARK: - UITableViewDataSource
extension ViewController: UITableViewDataSource {
        
        // Number of lines to be created in a View
        func tableView(_ tableView: UITableView,
                       numberOfRowsInSection section: Int) -> Int {
            return names.count
        }
        
        // Create cell per cell and asign a value typed by the user
        func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            
            let cell = tableView.dequeueReusableCell(withIdentifier: "Cell",
                                                     for: indexPath)
            
            cell.textLabel?.text = names[indexPath.row]
            
            return cell
        }
    }

