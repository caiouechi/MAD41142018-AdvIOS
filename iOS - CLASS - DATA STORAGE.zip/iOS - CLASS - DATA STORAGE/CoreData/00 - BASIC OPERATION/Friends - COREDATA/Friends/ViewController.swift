//
//  ViewController.swift
//  Friends
//
//  Created by Marcos Bittencourt on 2017-07-12.
//  Copyright © 2017 https://ca.linkedin.com/in/marcosbittencourt. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController {

    @IBOutlet weak var tableview: UITableView!
    
    //var names: [String] = []
     var people:[NSManagedObject] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        title = "My Friends"
        tableview.register(UITableViewCell.self,forCellReuseIdentifier: "Cell")
    }
    
    // ... begin Retrieve data previously stored
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        //1 : ... begin Creating a managed object for working with managed objects (store in disk).
        guard let appDelegate =
            UIApplication.shared.delegate as? AppDelegate else {
                return
        }
        
        let managedContext = appDelegate.persistentContainer.viewContext
        //1 : ... end Creating a managed object context for working with managed objects.
        
        
        //2 : Variable that will receive data retrieved from our Entities
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Person")
        
        //3 : Loop to read data store then in people (array created previously
        do {
            people = try managedContext.fetch(fetchRequest)
        } catch let error as NSError {
            print("Could not fetch. \(error), \(error.userInfo)")
        }
    }
    // ... end: Retrieve data previously stored

    @IBAction func addName(_ sender: Any) {
        
        // Create a Modal to receive data from user
        let alert = UIAlertController(title: "New Name",
                                      message: "Add a new name",
                                      preferredStyle: .alert)
        
        // Create a button save to be used in A Modal
        let saveAction = UIAlertAction(title: "Save", style: .default) {
            
            // Create a data Entry to the user. Type the name of your friend
            [unowned self] action in
            guard let textField = alert.textFields?.first,
                let nameToSave = textField.text
                else {
                    return
            }
            
            self.save(name : nameToSave) // Call func (save) to save data (comes from data entry)
            self.tableview.reloadData() //  Call reloadData() to refresh screen and release the modal
            
        }
        
        // Create a button cancel and release the modal
        let cancelAction = UIAlertAction(title: "Cancel", style: .default)
        
        // Adding ... propreties in Modal (save and cancel)
        alert.addTextField()
        alert.addAction(saveAction)
        alert.addAction(cancelAction)
        
        // Show the Modal to the user
        present(alert, animated: true)
        
    }
    
    func save(name: String) {
        
        guard let appDelegate =
            UIApplication.shared.delegate as? AppDelegate else {
                return
        }
        
        //1 : ... begin Creating a managed object for working with managed objects (store in disk).
        let managedContext =
            appDelegate.persistentContainer.viewContext
        
        // 2
        let entity =
            NSEntityDescription.entity(forEntityName: "Person",
                                       in: managedContext)!
        
        let person = NSManagedObject(entity: entity,
                                     insertInto: managedContext)
        
        // 3
        person.setValue(name, forKeyPath: "name")
        
        // 4
        do {
            try managedContext.save()
            people.append(person)
        } catch let error as NSError {
            print("Could not save. \(error), \(error.userInfo)")
        }
    }

    
}
    
// MARK: - UITableViewDataSource
extension ViewController: UITableViewDataSource {
        
        // Number of lines to be created in a View
        func tableView(_ tableView: UITableView,
                       numberOfRowsInSection section: Int) -> Int {
            return people.count
        }
        
        // Create cell per cell and asign a value typed by the user
        func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            
            let person = people[indexPath.row]
            let cell = tableView.dequeueReusableCell(withIdentifier: "Cell",
                                                     for: indexPath)
            
            cell.textLabel?.text = person.value(forKeyPath: "name") as? String
            
            return cell
        }
    }

